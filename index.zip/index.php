<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Blog</title>
    <link rel="shortcut icon" type="image/png" href="../favicon.png"/>
    <script src="/users/js/jquery-1.11.3.min.js"></script>
    <link rel="stylesheet" href="blog/css/bootstrap.css"/>
    <link rel="stylesheet" href="blog/css/font-awesome.css"/>
    <link rel="stylesheet" href="blog/css/gallery.css"/>
    <link rel="stylesheet" href="blog/css/custom.css"/>
    <link rel="stylesheet" href="css/bootstrap.css"/>
    <link rel="stylesheet" href="css/gallery.css"/>
    <link rel="stylesheet" href="css/custom.css"/>
    <script type="text/javascript">
        users_dir = 'http://'+window.location.hostname+'/users/';
        users_pic_dir = 'http://'+window.location.hostname+'/users/profile_pic/';
    </script>



    <?php

    include_once ("mysql.php");
    include_once($_SERVER['DOCUMENT_ROOT'].'/config.php');
    $servername = "mysql1.woofwarrior.com";
    $username = "waldoing_uploade";
    $password = "waldoing";
    $table = "woofwarr_users";

    $link = mysqli_connect($servername, $username, $password, $table);
    if (!$link) {
        die("Connection failed: " . mysqli_connect_error());
    }


    $servername = "mysql1.woofwarrior.com";
    $username = "waldoing_uploade";
    $password = "waldoing";
    $table = "woofwarr_blog";

    $conn = mysqli_connect($servername, $username, $password, $table);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }


    //mysqli_select_db($conn, "woofwarr_blog") or mysqli_connect_error();
    $sql = "SELECT  * FROM woofwarr_blog.forum_posts where post_owner='Woof Warrior' order by post_id desc limit 0,1";
    $sql1 = "SELECT  * FROM woofwarr_blog.forum_posts order by post_id desc limit 1,3";
    $userqry ="SELECT * FROM woofwarr_users.user order by userID desc limit 0,100";
    $useres = mysqli_query($link,$userqry);
    $result = mysqli_query($conn, $sql);
    $res1=mysqli_query($conn,$sql1);

    $tit="";
    $img="no_image.png";
    $ptext="";
    $pid="";

    while($row=mysqli_fetch_array($result))
    {

            $tit=$row['post_title'];

            $ptext=$row['post_text'];
            $pid=$row['post_id'];
            $img = $row['post_image'];

          }

    ?>
</head>

<body id="blog-page">

<div class="top-header">
    <div class="container">
        <div class="row">
            <div class="signup-wrap">
                <?php


                if(!isset($_SESSION['username']) && !isset($_SESSION['userID'])){


                    include("users/signup.html");
                }
                ?>

            </div>
            <?php


            if(isset($_SESSION['username']) && isset($_SESSION['userID'])){

                ?>


                <div> Hi <b><?php echo $_SESSION['username']; ?></b> </div>


                <div id="profilePic">

                    <?php
                    mysqli_select_db($link, $usersdb);


                    $res = mysqli_query($link, "SELECT `pic_name` FROM `profile_pic` WHERE `user_id`=".$_SESSION['userID'].";") or die(mysqli_error($conn));

                    $pic = mysqli_fetch_assoc($res);




                    if(!empty($pic)){

                        echo "<img src='".$users_pic_dir.'/'.$pic['pic_name']."' width=100 height=100 />";

                    }

                    ?>

                </div>

                <div>Score:

                    <?php

                    $res = mysqli_query($link, "SELECT `scoreAmount` FROM `scores` WHERE `userID`=".$_SESSION['userID'].";") or die(mysqli_error($conn));

                    $score = mysqli_fetch_assoc($res);

                    if(!empty($score)){

                        echo $score['scoreAmount'];

                    }else{

                        echo '0';

                    } ?>


                </div>


            <?php    } ?>

            <div class="button-wrapper">
                <ul>
                    <li><a href="http://woofwarrior.com/gallery"><img src="blog/images/voting-btn.png" alt=""/></a></li>
                    <li><a href="http://woofwarrior.com/games"><img src="blog/images/game-btn.png" alt=""/></a></li>
                    <li><a href="http://woofwarrior.com/woof"><img src="blog/images/blog-btn.png" alt=""/></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!--/.header -->

<header>
    <div class="container">
        <div class="blog-banner" href="https://www.kickstarter.com/projects/1207894074/1378311121?token=5209eb9d">
            <div class="row">

            </div>
        </div>
    </div>
</header>
<!--/.header -->

<div class="blog-content-wrapper">
    <div class="container">
        <div class="blog-content-post glow-blue">
            <div class="main-title">
                Check out Woof Warrior Post
            </div>
            <div class="title">
                <h3><a href="showpost.php?post_id=<?php echo $pid ;?>" ><?php echo $tit; ?></a></h3>
            </div>
            <div class="row">

                <div class="col-md-3">
                    <div class="img-box">
                        <!-- <img src="post_image/12235126_940199052722264_7795673716402237619_n.jpg" class="img-responsive" alt=""/> -->
                        <img src="post_image/<?php echo $img; ?>" class="img-responsive" alt=""/>
                    </div>
                </div>

                <div class="col-md-9">
                    <div class="text">
                        <p>
                            <?php echo $ptext; ?>
                        </p>


                    </div>
                    <div class="post-all">
                        <a href="">All Posts <i class="fa fa-arrow-right"></i></a>
                    </div>
                </div>

            </div>
        </div>

        <div class="blog-content-users glow-blue">
            <div class="main-title">
                New Users
            </div>

            <div class="row">
                <div class="col-md-12"  style="margin-top:10px" >
                    <?php
                    while($row2=mysqli_fetch_array($useres))
                    {
                        ?>
                        <div class="col-md-2">
                            <div class="img-box">
                                <img src="img/dog-paw.jpeg" height=100 width=100 />
                            </div>
                            <div><a href="<?php echo $users_dir_view.'?username='.$row2['username']; ?>"/> >
                                    <?php
                                    if($row2['username'] != '' )
                                    {
                                        ?> <script>console.log(<?php echo $row2['username']?>); </script><?php
                                        echo $row2['username'];
                                    }
                                    else
                                    {
                                        echo "DOG Friend";
                                    }




                                    ?></a></div>
                        </div>
                        <?php
                    }
                    ?>

                </div>
            </div>
        </div>

        <div class="blog-content-discussion glow-blue">
            <div class="main-title">
                All Discussions
            </div>

            <div class="row" style="margin-top:10px">
                <?php
                while($row1=mysqli_fetch_array($res1))
                {
                    ?>
                    <div class="col-md-3">
                        <div class="img-box">
                            <img src="img/dog-paw.jpeg" height=100 width=100 />
                        </div>
                        <div><a href="showpost.php?post_id=<?php echo $row1['post_id'] ;?>" > <?php echo $row1['post_owner']; ?></a></div>
                    </div>
                    <?php
                }
                ?>

            </div>
            <div class="post-all">
                <a href="">All Posts <i class="fa fa-arrow-right"></i></a>
            </div>
        </div>
    </div>
</div>
</div>


<footer style="margin-top:50px">
    <?php include("footer2.php") ?>
</footer>
</body>
</html>

