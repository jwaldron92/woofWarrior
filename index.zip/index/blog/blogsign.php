<!DOCTYPE html>
<html>
<head>
    <title>Blog</title>
    <link rel="shortcut icon" type="image/png" href="../favicon.png"/>
    <link rel="stylesheet" href="css/bootstrap.css"/>
    <link rel="stylesheet" href="css/font-awesome.css"/>
    <link rel="stylesheet" href="css/gallery.css"/>
    <link rel="stylesheet" href="css/custom.css"/>

</head>

<body id="blog-page">


<header class="blog-top-header">

    <div class="container">
        <div class="row">


                       <div class="signup-wrap">
               <?php
               if(!isset($_SESSION['username']) && !isset($_SESSION['userID'])){
                   mysqli_select_db($link, $usersdb);


                   print ' <div>Want to Join?</a></div>';
                   include($_SERVER['DOCUMENT_ROOT'].'/users/signup.html');
               }
               ?>
           </div>
        </div>
    </div>
</header>
<!--/.header -->

<div class="blog-banner">
    <div class="button-wrapper">
        <ul>
            <li><a href="https://woofwarrior.com/gallery"><img src="images/voting-btn.png" alt=""/></a></li>
            <li><a href="https://woofwarrior.com/games"><img src="images/game-btn.png" alt=""/></a></li>
            <li><a href="https://woofwarrior.com/woof"><img src="images/blog-btn.png" alt=""/></a></li>
        </ul>
    </div>
</div>

<div class="blog-content-wrapper">
    <div class="container">
        <div class="blog-content-post">
            <div class="main-title">
                Check out Woo Warrior Post
            </div>
            <div class="title">
                <h3>Title Here</h3>
            </div>
            <div class="row">

                    <div class="col-md-3">
                        <div class="img-box">
                            <img src="images/b1.png" class="img-responsive" alt=""/>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="text">
                            <p>
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been the industry's standard dummy text ever since the 1500s, when an unknown printer
                                took a galley of type and scrambled it to make a type specimen book. It has survived not
                                only five centuries, but also the leap into electronic typesetting, remaining essentially
                                unchanged. It was popularised in the 1960s with the release of Letraset sheets
                                containing Lorem Ipsum passages, a
                                nd more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                            </p>
                            <p>
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been the industry's standard dummy text ever since the 1500s, when an unknown printer
                                took a galley of type and scrambled it to make a type specimen book. It has survived not
                                only five centuries, but also the leap into electronic typesetting, remaining essentially
                                unchanged. It was popularised in the 1960s with the release of Letraset sheets
                                containing Lorem Ipsum passages, a
                                nd more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                            </p>


                        </div>
                        <div class="post-all">
                            <a href="">All Post <i class="fa fa-arrow-right"></i></a>
                        </div>
                    </div>

            </div>
        </div>

        <div class="blog-content-users">
            <div class="main-title">
                New Users
            </div>

            <div class="row">
                <div class="col-md-12">
				<?php/*
					$servername = "50.87.248.243";
					$username = "woofwarr_ui";
					$password = "WoofWednesday1.";
					$table = "woofwarr_blog";

					$conn = new mysqli($servername, $username, $password, $table);

					// Check connection
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					}
					$sql = "SELECT fp.post_text FROM forum_posts fp WHERE fp.post_create_time = (SELECT MAX(fp1.post_create_time) FROM forum_posts	fp1)";
					$sql = "select * from forum_posts";
					$result = mysqli_query($conn, $sql);
					
					if (mysqli_num_rows($result) > 0) {
						// output data of each row
						echo "asdfasdf";
						while($row = mysqli_fetch_assoc($result)) {
							echo "text:" . $row["post_text"];
						}
					} else {
						echo "0 results";
					}
					mysqli_close($conn);
				*/?>
                </div>
            </div>
        </div>

        <div class="blog-content-discussion">
            <div class="main-title">
                All discussion
            </div>

            <div class="row">

                <div class="col-md-12">

                </div>


            </div>
            <div class="post-all">
                <a href="">All Post <i class="fa fa-arrow-right"></i></a>
            </div>
        </div>
    </div>
</div>



</body>
</html>
