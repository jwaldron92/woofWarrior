<?php
					$servername = "localhost";
					$username = "woofwarr_ui";
					$password = "WoofWednesday1.";
					$table = "woofwarr_blog";

					$conn = new mysqli($servername, $username, $password, $table);

					// Check connection
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					}
					$sql = "SELECT  * FROM woofwarr_blog.forum_posts order by post_id desc limit 0,1";
					$sql1 = "SELECT  * FROM woofwarr_blog.forum_posts order by post_id desc limit 1,3";
					$userqry="SELECT * FROM woofwarr_users.user a, woofwarr_users.url b where a.userID = b.userID order by a.userID desc limit 0,5";
					$result = mysqli_query($conn, $sql);
					$res1=mysqli_query($conn,$sql1);
								$useres=mysqli_query($conn,$userqry);
					$tit="";
					$img="";
					$ptext="";
					$pid="";
					while($row=mysqli_fetch_array($result))
					{
						$tit=$row['post_title'];
						$img=$row['post_image'];
						$ptext=$row['post_text'];
							$pid=$row['post_id'];
						
					}
					?>
<!DOCTYPE html>
<html>
<head>
    <title>Blog</title>
    <link rel="shortcut icon" type="image/png" href="../favicon.png"/>
    <link rel="stylesheet" href="css/bootstrap.css"/>
    <link rel="stylesheet" href="css/font-awesome.css"/>
    <link rel="stylesheet" href="css/gallery.css"/>
    <link rel="stylesheet" href="css/custom.css"/>

</head>

<body id="blog-page">


<header class="blog-top-header">

    <div class="container">
        <div class="row">


            <div class="col-md-12 col-sm-7">
                <ul>
                    <li><a href=""><span>Username</span></a></li>
                    <li><a href=""><span>E-mail</span></a></li>
                    <li><a href=""><span>New Password</span></a></li>
                    <li><a href=""><span>Sign up</span></a></li>
                </ul>
            </div>
        </div>
    </div>
</header>
<!--/.header -->

<div class="blog-banner">
    <div class="button-wrapper">
        <ul>
            <li><a href=""><img src="images/voting-btn.png" alt=""/></a></li>
            <li><a href=""><img src="images/game-btn.png" alt=""/></a></li>
            <li><a href=""><img src="images/blog-btn.png" alt=""/></a></li>
        </ul>
    </div>
</div>

<div class="blog-content-wrapper">
    <div class="container">
        <div class="blog-content-post">
            <div class="main-title">
                Check out Woof Warrior Post
            </div>
            <div class="title">
                <h3><a href="../showpost.php?post_id=<?php echo $pid ;?>" ><?php echo $tit; ?></a></h3>
            </div>
            <div class="row">

                    <div class="col-md-3">
                        <div class="img-box">
                            <img src="../post_image/<?php echo $img; ?>" class="img-responsive" alt=""/>
                        </div>
                    </div>
				
                    <div class="col-md-9">
                        <div class="text">
                            <p>
                                <?php echo $ptext; ?>
                            </p>
                          

                        </div>
                        <div class="post-all">
                            <a href="">All Posts <i class="fa fa-arrow-right"></i></a>
                        </div>
                    </div>

            </div>
        </div>

        <div class="blog-content-users">
            <div class="main-title">
                New Users
            </div>

            <div class="row">
                <div class="col-md-12"  style="margin-top:10px" >
				<?php
							while($row2=mysqli_fetch_array($useres))
							{
						?>
                <div class="col-md-2">
						<div class="img-box">
						<img src="images/dog-paw.jpeg" height=100 width=100 />
						</div>
						<div><a href="wooofwarrior.com/<?php echo $row2['urlAdress']; ?>" > 
						<?php 
						if($row2['username'] != '' )
						{
							echo $row2['username'];
						}
						else
						{
							echo "DOG Friend";
						}
						
						
						
						
						?></a></div>
                </div>
			<?php
							}
						?>
	
            </div>
                </div>
            </div>

        <div class="blog-content-discussion">
            <div class="main-title">
                All Discussions
            </div>
			
            <div class="row" style="margin-top:10px">
<?php
							while($row1=mysqli_fetch_array($res1))
							{
						?>
                <div class="col-md-3">
						<div class="img-box">
						<img src="images/dog-paw.jpeg" height=100 width=100 />
						</div>
						<div><a href="../showpost.php?post_id=<?php echo $row1['post_id'] ;?>" > <?php echo $row1['post_owner']; ?></a></div>
                </div>
<?php
							}
						?>
	
            </div>
            <div class="post-all">
                <a href="">All Posts <i class="fa fa-arrow-right"></i></a>
            </div>
        </div>
                </div>
    </div>
</div>



</body>
</html>
