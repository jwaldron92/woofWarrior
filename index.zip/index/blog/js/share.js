$(document).ready(function(){
	$.ajax({
		type:'post',
		url:'share.php',
		data:{postID:postID},
		success:function(data){
			data = JSON.parse(data);
			if(data == 'admin'){
				$('#shareButton').html('<input type=button id=share value=share onclick="api()" /><div id="fb-root"></div>');

				(function(d, s, id) {
					var js, fjs = d.getElementsByTagName(s)[0];
					if (d.getElementById(id)) return;
					js = d.createElement(s); js.id = id;
					js.src = "//connect.facebook.net/en_EN/sdk.js#xfbml=1&version=v2.5&appId=936089563130570";
					fjs.parentNode.insertBefore(js, fjs);
				}(document, 'script', 'facebook-jssdk'));

			}
		}
	})
})


function api(){
	FB.ui({
    	method: 'share',
   		href: window.location.href,
   	},
	// callback
	function(response) {
		console.log(response);
    	if(response && !response.error_message) {
      		FB.api('/me', function(response) {
      			$.ajax({
      				type:'post',
      				url:'share.php',
      				data:{id:response.id},
      				success:function(data){
      					console.log(data);
      				}		
      			})
			});
    	}else{
     		alert('Error while posting.');
		}
	});
}

