<!DOCTYPE html>
<html>
<head>
    <title>Blog</title>
    <link rel="shortcut icon" type="image/png" href="../favicon.png"/>
    <link rel="stylesheet" href="css/bootstrap.css"/>
    <link rel="stylesheet" href="css/font-awesome.css"/>
    <link rel="stylesheet" href="css/gallery.css"/>
    <link rel="stylesheet" href="css/custom.css"/>

</head>
<?php 
/* Short and sweet */
define('WP_USE_THEMES', false);
require('../wp-blog-header.php');

$posts = get_posts('numberposts=1&order=DESC&orderby=post_date');
foreach ($posts as $post) : setup_postdata( $post ); ?>
<img src="<?php post_thumbnail(); ?>"</img>
<h3><?php the_title(); ?> </h3>   
<p><?php the_excerpt(); ?> </p>
<?php
endforeach;
?>


<body id="blog-page">


<header class="blog-top-header">

    <div class="container">
        <div class="row">


            <div class="col-md-12 col-sm-7">
                <ul>
                    <li><a href=""><span>Username</span></a></li>
                    <li><a href=""><span>E-mail</span></a></li>
                    <li><a href=""><span>New Password</span></a></li>
                    <li><a href=""><span>Sign up</span></a></li>
                </ul>
            </div>
        </div>
    </div>
</header>
<!--/.header -->

<div class="blog-banner">
    <div class="button-wrapper">
        <ul>
            <li><a href=""><img src="images/voting-btn.png" alt=""/></a></li>
            <li><a href=""><img src="images/game-btn.png" alt=""/></a></li>
            <li><a href=""><img src="images/blog-btn.png" alt=""/></a></li>
        </ul>
    </div>
</div>

<div class="blog-content-wrapper">
    <div class="container">
        <div class="blog-content-post">
            <div class="main-title">
                Check out Woo Warrior Post
            </div>
            <div class="title">
                <h3><?php post_title() ?></h3>
            </div>
            <div class="row">

                    <div class="col-md-3">
                        <div class="img-box">
                               <img src="<?php post_thumbnail() ?>" width="275px" height="200" />

                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="text">
                            <p><?php the_excerpt() ?>
                        </div>
                        <div class="post-all">
                            <a href="">All Post <i class="fa fa-arrow-right"></i></a>
                        </div>
                    </div>

            </div>
        </div>

        <div class="blog-content-users">
            <div class="main-title">
                New Users
            </div>

            <div class="row">
                <div class="col-md-12">

                </div>
            </div>
        </div>

        <div class="blog-content-discussion">
            <div class="main-title">
                All discussion
            </div>

            <div class="row">

                <div class="col-md-12">

                </div>


            </div>
            <div class="post-all">
                <a href="">All Post <i class="fa fa-arrow-right"></i></a>
            </div>
        </div>
    </div>
</div>



</body>
</html>
