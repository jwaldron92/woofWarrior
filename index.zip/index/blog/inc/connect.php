<?php


$server ="localhost";
$user = 'woofwarr_ui';
$password = 'WoofWednesday1.';
$blogdb = 'woofwarr_blog';

//connect to server and select database; you may need it
$link = mysqli_connect($server, $user, $password);

if (mysqli_connect_errno()) {
	printf("Connect failed: %s\n", mysqli_connect_error());
	exit();
}
else {
printf("Connection Successful");}
mysqli_select_db($link, $blogdb);

?>