<!DOCTYPE html>
<html>
<head>
    <title>Blog</title>
    <link rel="shortcut icon" type="image/png" href="../favicon.png"/>
    <link rel="stylesheet" href="css/bootstrap.css"/>
    <link rel="stylesheet" href="css/font-awesome.css"/>
    <link rel="stylesheet" href="css/gallery.css"/>
    <link rel="stylesheet" href="css/custom.css"/>

</head>

<body id="blog-page">


<header class="blog-top-header">

    <div class="container">
        <div class="row">


            <div class="col-md-12 col-sm-7">
                <ul>
                    <li><a href=""><span>Username</span></a></li>
                    <li><a href=""><span>E-mail</span></a></li>
                    <li><a href=""><span>New Password</span></a></li>
                    <li><a href=""><span>Sign up</span></a></li>
                </ul>
            </div>
        </div>
    </div>
</header>
<!--/.header -->

<div class="blog-banner">
    <div class="button-wrapper">
        <ul>
            <li><a href=""><img src="images/voting-btn.png" alt=""/></a></li>
            <li><a href=""><img src="images/game-btn.png" alt=""/></a></li>
            <li><a href=""><img src="images/blog-btn.png" alt=""/></a></li>
        </ul>
    </div>
</div>

<div class="blog-content-wrapper">
    <div class="container">
        <div class="blog-content">

        </div>
    </div>
</div>
</body>
</html>