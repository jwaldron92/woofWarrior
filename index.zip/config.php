<?php
//path to users dir
$domain = 'http://woofwarrior.com/';

$gallery_dir = $domain.'gallery/';

$blog_dir = $domain.'woof/';

$users_dir = $domain.'users/';
$users_dir_view = $domain.'users/view.php';
$users_pic_dir = $domain.'users/profile_pic';



?>

