$(document).ready(function(){
    getPostsAjax();
})

$(window).scroll(function() {
    if($(window).scrollTop() + $(window).height() == $(document).height()) {
        getPostsAjax({lastPost:$('.post_block:last').attr('id')});
    }
});

function getPostsAjax(){
    $.ajax({
        type:'POST',
        url:'posts.php/getFirst',
        data:{action:'getFirst'},
        success:function(data) {
            //console.log(data[0], data[1], data[2]);
            var data = data;
            console.log(data[0], data[1], data[2]);
            data = JSON.parse(data);
            for (i = 0; i < data.length; i++) {
                
                if (data[i]['post_owner'] == 'Woof Warrior') {

                    //$('#adminPosts').append("<div class=adminBlock id=" + data[i]['post_id'] + "><a href='showpost.php?post_id=" + data[i]['post_id'] + "'><div>" + data[i]['post_title'] + "</div><div><img src='post_image/" + data[i]['post_image'] + "' alt='post image' class=post_image /></div></a></div>");
                    $('#adminPosts').append("<div class=post_block id="+data[i]['post_id']+"><a href='showpost.php?post_id="+data[i]['post_id']+"'><div>"+data[i]['post_create_time']+"</div><div><img src='post_image/"+data[i]['post_image']+"' alt='post image' class=post_image /></div><div>"+data[i]['post_title']+"</div></a></div>");
                } else {

                    //$('#allPosts').append("<div class=userBlock id=" + data[i]['post_id'] + "><div><a href='showpost.php?post_id=" + data[i]['post_id'] + "'>" + data[i]['post_title'] + "</a></div></div>")
                    $('#allPosts').append("<div class=post_block id="+data[i]['post_id']+"><a href='showpost.php?post_id="+data[i]['post_id']+"'><div>"+data[i]['post_create_time']+"</div><div><img src='post_image/"+data[i]['post_image']+"' alt='post image' class=post_image /></div><div>"+data[i]['post_title']+"</div></a></div>");
                }

            }
        }

    })

}